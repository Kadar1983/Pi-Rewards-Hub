import Layout from '../components/Layout';
import Card from '../components/Card';

export default function Rewards() {
  return (
    <Layout>
      <Card title="Daily Rewards">
        <p>Claim your daily reward here.</p>
      </Card>
    </Layout>
  )
}
