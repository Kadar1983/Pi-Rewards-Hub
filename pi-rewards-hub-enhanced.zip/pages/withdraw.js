import Layout from '../components/Layout';
import Card from '../components/Card';
import {useState, useEffect} from 'react';

export default function Withdraw() {
  const [kyc, setKyc] = useState('unknown');
  const [amount, setAmount] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(()=>{
    // fetch user KYC status (placeholder)
    setKyc('pending');
  },[]);

  const requestWithdraw = async ()=>{
    const res = await fetch('/api/withdraw', {method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({amount})});
    const j = await res.json();
    setMsg(j.message || 'طلب تم');
  }

  return (
    <Layout>
      <Card title="Withdraw">
        <p className="text-sm mb-2">KYC status: <strong className='ml-1'>{kyc}</strong></p>
        <p className="text-sm mb-4">إذا كانت حالة KYC مكتملة ستتمكن من السحب مباشرة.</p>
        <input value={amount} onChange={e=>setAmount(e.target.value)} placeholder='Amount in Pi' className='w-full mb-3 p-2 rounded-lg bg-white/5' />
        <button onClick={requestWithdraw} className='px-4 py-2 rounded-xl bg-accent text-black font-semibold'>Request Withdraw</button>
        {msg && <p className='mt-3 text-sm'>{msg}</p>}
      </Card>
    </Layout>
  )
}
